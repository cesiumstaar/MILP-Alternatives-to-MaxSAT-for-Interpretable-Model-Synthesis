python3 -m venv venv
source venv/bin/activate
pip install -U python-sat
pip install gurobipy tabulate pandas scikit-learn
pip install tensorflow==2.15.0